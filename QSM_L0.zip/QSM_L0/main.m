close all; clear all;clc;
load all_data; 

%%%     all_data file includes: B0_dir,delta_TE,voxel_size,CF,Mask,RDF
%%%     RDF--the input data without background field
%%%     voxel_size - the size of a voxel
%%%     TE - the echo time 
%%%     CF - Gyromagnetic ratio
%%%     B0_dir - the direction of the B0 field

slice_no = ceil(size(RDF,3)/2-10);  %%%    slice number
scale_fig = [-0.15,0.15];

para.voxel_size = voxel_size; 
para.delta_TE = delta_TE; 
para.CF = CF; 
para.B0_dir = B0_dir;
para.scale_fig = scale_fig;

Output = QSM_L0(RDF,Mask,para,slice_no);