function [  ] = plot_axialSagittalCoronal( vol, scale_fig, slice_no,flag, title_fig )
%PLOT_AXIALSAGITTALCORONAL Summary of this function goes here
%   Detailed explanation goes here
if flag==1
    % im_size = round(size(vol)/2)-2;
    figure, imagesc( vol(:,:,slice_no), scale_fig  ), axis square off, colormap gray
elseif flag==2
    figure, imagesc( imrotate(squeeze(vol(:,slice_no,:)),90), scale_fig  ), axis square off, colormap gray
elseif flag==3
    figure, imagesc( imrotate(squeeze(vol(slice_no,:,:)),90), scale_fig  ), axis square off, colormap gray
elseif flag==4
    [k1,k2,k3]=size(vol);
    figure;
    subplot(131),imagesc( vol(:,:,round(k3/2)), scale_fig  ), axis square off, colormap gray
    subplot(132),imagesc( imrotate(squeeze(vol(:,round(k2/2),:)),90), scale_fig  ), axis square off, colormap gray
    subplot(133),imagesc( imrotate(squeeze(vol(round(k1/2),:,:)),90), scale_fig  ), axis square off, colormap gray
else
    return;
end

% figure(fig_no), imagesc( vol(:,:,im_size(3)), scale_fig  ), axis square off, colormap gray
% figure(fig_no), imagesc( imrotate(squeeze(vol(im_size(1),:,:)),90), scale_fig  ), axis square off, colormap gray
% figure(fig_no), imagesc( imrotate(squeeze(vol(:,im_size(2),:)),90), scale_fig  ), axis square off, colormap gray
if nargin == 5
    title(title_fig)
end

drawnow

end


